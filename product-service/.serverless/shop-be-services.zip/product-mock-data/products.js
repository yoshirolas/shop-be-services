const products = [
    {
        id: '1',
        productName: 'Product 1',
        title: 'Product 1',
        price: 100,
        currency: '$',
    },
    {
        id: '2',
        productName: 'Product 2',
        title: 'Product 2',
        price: 100,
        currency: '$',
    },
    {
        id: '3',
        productName: 'Product 3',
        title: 'Product 3',
        price: 100,
        currency: '$',
    },
];

module.exports = { products };