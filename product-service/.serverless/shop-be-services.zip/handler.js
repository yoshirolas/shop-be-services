'use strict';
const {products} = require('./product-mock-data/products')

module.exports.products = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify(products)
  };
};

module.exports.product = async (event) => {
  console.log('event 123', event)
  const {id} = event.pathParameters;
  // return {
  //   statusCode: 200,
  //   body: JSON.stringify(id)
  // }

  if (!id) {
    return {
      statusCode: 404,
      body: 'Error! Please use the following path structure: /product/{id}'
    };
  }
  const product = products.find(p => p.id === id);
  if (!product) {
    return {
      statusCode: 404,
      body: `Error! Couldn't find product with id ${id}`
    };
  }
  return {
    statusCode: 200,
    body: JSON.stringify(
      product
    ),
  };
};
